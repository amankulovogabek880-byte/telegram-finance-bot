import asyncio
import logging
import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage

TOKEN = "8313872666:AAHeI6a2kw2sM4eMpc-FQTLHjGL1-OzD1aw"

logging.basicConfig(level=logging.INFO)

bot = Bot(token=TOKEN)
dp = Dispatcher(storage=MemoryStorage())

DB_NAME = "database.db"


# ================= DATABASE =================

async def init_db():
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            name TEXT
        )
        """)

        await db.execute("""
        CREATE TABLE IF NOT EXISTS cargo (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            name TEXT,
            weight INTEGER,
            price INTEGER,
            phone TEXT,
            from_city TEXT,
            to_city TEXT
        )
        """)

        await db.execute("""
        CREATE TABLE IF NOT EXISTS trucks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            model TEXT,
            capacity INTEGER,
            phone TEXT,
            from_city TEXT,
            to_city TEXT
        )
        """)

        await db.commit()


# ================= STATES =================

class CargoForm(StatesGroup):
    name = State()
    weight = State()
    price = State()
    phone = State()
    from_city = State()
    to_city = State()


class TruckForm(StatesGroup):
    model = State()
    capacity = State()
    phone = State()
    from_city = State()
    to_city = State()


# ================= HELPERS =================

def is_number(text):
    return text.isdigit()


def is_text(text):
    return text.replace(" ", "").isalpha()


# ================= START =================

@dp.message(CommandStart())
async def start(message: types.Message):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users (id, name) VALUES (?, ?)",
            (message.from_user.id, message.from_user.full_name)
        )
        await db.commit()

    keyboard = types.ReplyKeyboardMarkup(
        keyboard=[
            [types.KeyboardButton(text="📦 Yuk joylash")],
            [types.KeyboardButton(text="🚚 Truck joylash")],
            [types.KeyboardButton(text="📋 Yuklar ro‘yxati")],
            [types.KeyboardButton(text="📋 Trucklar ro‘yxati")]
        ],
        resize_keyboard=True
    )

    await message.answer("Xush kelibsiz! Kerakli bo‘limni tanlang:", reply_markup=keyboard)


# ================= CARGO =================

@dp.message(lambda m: m.text == "📦 Yuk joylash")
async def cargo_start(message: types.Message, state: FSMContext):
    await message.answer("Yuk nomini kiriting (faqat harflar):")
    await state.set_state(CargoForm.name)


@dp.message(CargoForm.name)
async def cargo_name(message: types.Message, state: FSMContext):
    if not is_text(message.text):
        await message.answer("❌ Faqat harflar kiriting!")
        return

    await state.update_data(name=message.text)
    await message.answer("Og‘irligini kiriting (faqat son):")
    await state.set_state(CargoForm.weight)


@dp.message(CargoForm.weight)
async def cargo_weight(message: types.Message, state: FSMContext):
    if not is_number(message.text):
        await message.answer("❌ Faqat son kiriting!")
        return

    await state.update_data(weight=int(message.text))
    await message.answer("Narxini kiriting (faqat son):")
    await state.set_state(CargoForm.price)


@dp.message(CargoForm.price)
async def cargo_price(message: types.Message, state: FSMContext):
    if not is_number(message.text):
        await message.answer("❌ Faqat son kiriting!")
        return

    await state.update_data(price=int(message.text))
    await message.answer("Telefon raqamni kiriting:")
    await state.set_state(CargoForm.phone)


@dp.message(CargoForm.phone)
async def cargo_phone(message: types.Message, state: FSMContext):
    if not is_number(message.text):
        await message.answer("❌ Telefon raqam faqat son bo‘lishi kerak!")
        return

    await state.update_data(phone=message.text)
    await message.answer("Qayerdan (shahar, faqat harflar):")
    await state.set_state(CargoForm.from_city)


@dp.message(CargoForm.from_city)
async def cargo_from(message: types.Message, state: FSMContext):
    if not is_text(message.text):
        await message.answer("❌ Shahar nomi faqat harflardan iborat bo‘lishi kerak!")
        return

    await state.update_data(from_city=message.text)
    await message.answer("Qayerga (shahar, faqat harflar):")
    await state.set_state(CargoForm.to_city)


@dp.message(CargoForm.to_city)
async def cargo_to(message: types.Message, state: FSMContext):
    if not is_text(message.text):
        await message.answer("❌ Shahar nomi faqat harflardan iborat bo‘lishi kerak!")
        return

    data = await state.get_data()

    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
        INSERT INTO cargo (user_id, name, weight, price, phone, from_city, to_city)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            message.from_user.id,
            data["name"],
            data["weight"],
            data["price"],
            data["phone"],
            data["from_city"],
            message.text
        ))
        await db.commit()

    await message.answer("✅ Yuk muvaffaqiyatli saqlandi!")
    await state.clear()


# ================= CARGO LIST =================

@dp.message(lambda m: m.text == "📋 Yuklar ro‘yxati")
async def cargo_list(message: types.Message):
    async with aiosqlite.connect(DB_NAME) as db:
        cursor = await db.execute("SELECT name, weight, price, phone, from_city, to_city FROM cargo")
        rows = await cursor.fetchall()

    if not rows:
        await message.answer("Hozircha yuklar yo‘q.")
        return

    text = "📦 Yuklar ro‘yxati:\n\n"
    for r in rows:
        text += f"""
📦 {r[0]}
⚖ {r[1]} kg
💰 {r[2]}
📞 {r[3]}
📍 {r[4]} → {r[5]}

"""

    await message.answer(text)


# ================= TRUCK =================

@dp.message(lambda m: m.text == "🚚 Truck joylash")
async def truck_start(message: types.Message, state: FSMContext):
    await message.answer("Truck modeli (faqat harflar):")
    await state.set_state(TruckForm.model)


@dp.message(TruckForm.model)
async def truck_model(message: types.Message, state: FSMContext):
    if not is_text(message.text):
        await message.answer("❌ Faqat harflar kiriting!")
        return

    await state.update_data(model=message.text)
    await message.answer("Sig‘imi (kg, faqat son):")
    await state.set_state(TruckForm.capacity)


@dp.message(TruckForm.capacity)
async def truck_capacity(message: types.Message, state: FSMContext):
    if not is_number(message.text):
        await message.answer("❌ Faqat son kiriting!")
        return

    await state.update_data(capacity=int(message.text))
    await message.answer("Telefon raqam:")
    await state.set_state(TruckForm.phone)


@dp.message(TruckForm.phone)
async def truck_phone(message: types.Message, state: FSMContext):
    if not is_number(message.text):
        await message.answer("❌ Telefon faqat son bo‘lishi kerak!")
        return

    await state.update_data(phone=message.text)
    await message.answer("Qayerdan (shahar, faqat harflar):")
    await state.set_state(TruckForm.from_city)


@dp.message(TruckForm.from_city)
async def truck_from(message: types.Message, state: FSMContext):
    if not is_text(message.text):
        await message.answer("❌ Shahar faqat harflardan iborat bo‘lishi kerak!")
        return

    await state.update_data(from_city=message.text)
    await message.answer("Qayerga (shahar, faqat harflar):")
    await state.set_state(TruckForm.to_city)


@dp.message(TruckForm.to_city)
async def truck_to(message: types.Message, state: FSMContext):
    if not is_text(message.text):
        await message.answer("❌ Shahar faqat harflardan iborat bo‘lishi kerak!")
        return

    data = await state.get_data()

    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
        INSERT INTO trucks (user_id, model, capacity, phone, from_city, to_city)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (
            message.from_user.id,
            data["model"],
            data["capacity"],
            data["phone"],
            data["from_city"],
            message.text
        ))
        await db.commit()

    await message.answer("✅ Truck muvaffaqiyatli saqlandi!")
    await state.clear()


# ================= TRUCK LIST =================

@dp.message(lambda m: m.text == "📋 Trucklar ro‘yxati")
async def truck_list(message: types.Message):
    async with aiosqlite.connect(DB_NAME) as db:
        cursor = await db.execute("SELECT model, capacity, phone, from_city, to_city FROM trucks")
        rows = await cursor.fetchall()

    if not rows:
        await message.answer("Hozircha trucklar yo‘q.")
        return

    text = "🚚 Trucklar ro‘yxati:\n\n"
    for r in rows:
        text += f"""
🚚 {r[0]}
⚖ {r[1]} kg
📞 {r[2]}
📍 {r[3]} → {r[4]}

"""

    await message.answer(text)


# ================= RUN =================

async def main():
    await init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
